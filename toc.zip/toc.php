<?php
/**
 * @package Tiaozhanshu's_Table_Of_Contents
 * @author Jan
 * @version 1.0
 */
/*
Plugin Name: Tiaozhanshu's Table Of Contents
Version: 1.0
Plugin URI: http://www.tiaozhanshu.net/table-of-contents/
Description: Scans through HTML headings and creates a "Table of Contents" list for your posts/pages. Access it via &lt;!--TOC--&gt; inside your post.
Author: Jan
Author URI: http://www.tiaozhanshu.net/
*/

class TableOfContents {
	var $toc;
	var $stack;
	var $start;
	var $pos;

	function toc_filter($content) {
		// Return original content if no toc tag was found
		if ( strpos($content, '<!--TOC-->') === false ) return $content;
		// 类的对象将被重用，所以*必须*在filter里初始化！否则影响两次执行filter的页面，比如feed。
		$this->toc = '';
		$this->stack = array();
		$this->start = 0;
		$this->pos = 0;

		$regex = '|<h([1-6])([^>]*)>(.*)</h\1>|mu';//(.*?)
		$content = preg_replace_callback($regex, array(&$this, 'replace_heading'), $content);
		$this->deep_process_toc();
		$content = str_replace('<!--TOC-->', $this->toc, $content);
	return $content;
	}

	function replace_heading($matches) {
		$toc = &$this->toc;	
		$stack = &$this->stack;
		$start = &$this->start;
		$pos = &$this->pos;
		$level = intval($matches[1])-$start;
		$text = $matches[3];
		if ( empty($stack) ) {
			$stack = array_fill(0, 6-$start+1, 0);
			$start = $level;
			$level = 0;
			$stack[$level] = 1;
			$pos = $level;
			$toc = '<ol><li>' . $this->get_toclink($text);
		} elseif ( $level <= $pos) {
			while ( $level < $pos ) {
				$pos--;
				$toc .= '</li></ol>';
			}
			$stack[$level]++;
			$toc .= "</li>\n<li>" . $this->get_toclink($text);
		} else {
			$pos++;
			$stack[$pos]=1;
			$toc .= "<ol><li>" . $this->get_toclink($text);
		}
		return "<h{$matches[1]} id=\"" . $this->get_tocid() . "\"{$matches[2]}>{$matches[3]}</h{$matches[1]}>";
	}

	function get_tocid() {
		return 'toc-' . implode('-', array_slice($this->stack, 0, $this->pos + 1));
	}

	function get_toclink($text) {
		return '<a href="#' . $this->get_tocid() . "\">$text</a>";
	}

	function deep_process_toc() {
		$toc = &$this->toc;	
            $options = get_option('toc');
	for ($i = 0; $i <= $this->pos; $i++)
			$toc .= "</li></ol>";
		$titlepaddingsize = 2;
		$insidepaddingsize = 8;
		$bordercolor = '#D0DDD0';
		$bordersize = 1;
		$backcolor = '#F0FFF0';
		$offsetsub = ($insidepaddingsize + $bordersize)*2;
		if( $options['style'] == 'yskin' ) {
			$tochead = <<<EOA
<div id="toc" style="float:right;margin:0 0 5px 8px;padding:0"><div onclick="javascript:var tocmain = document.getElementById('toc');var toctitle = document.getElementById('toctitle');var toc = document.getElementById('tocinside');if(toc.style.display == 'none') {toc.style.display = tocWas;tocmain.className = '';}else{toctitle.style.width = (toc.offsetWidth-{$offsetsub}).toString()+'px';tocWas = toc.style.display;toc.style.display = 'none';tocmain.className = 'toc-hidden';}" id="toctitle" style="margin:0 0 4px 0;padding:3px {$insidepaddingsize}px;font-weight:bold;text-align:center;border:{$bordersize}px solid {$bordercolor};background:{$backcolor};cursor:pointer;">
EOA;
			$tochead .= $options[title];
			$tochead .= <<<EOA
</div><div id="tocinside" style="margin:4px 0 0 0;padding:{$titlepaddingsize}px;border:{$bordersize}px solid {$bordercolor};background:{$backcolor}">
EOA;
			$toc = $tochead . $toc . "</div></div>\n";
		}
		else if ( $options['style'] == 'simple' ) {
			if( $options['title']!=NULL ) $toc = '<li style="list-style:none;">'.$options['title'].'</li><li style="list-style:none;">'.$toc.'</li>';
		}
	}
}

function toc_options_page() {
    $options = get_option('toc');
    if( isset($_POST) ) {
        if( isset($_POST['update_setting']) ){
            $options['style'] = $_POST['style'];
			$options['title'] = $_POST['title'];
            update_option('TOC',$options);
        }
    }
?>
<div class="wrap">
	<h2 style="border:none">Table Of Contents Options</h2>
		<div class="toc-head" style="border:none;padding-top:0px;padding-bottom:10px;border-bottom:1px solid #DADADA;">
		<p>基于Yskin的Table Of Contents改变而来，增加了选择功能。可以选择简单风格或者原Yskin风格。<br/>该插件会自动搜索文章中的h1~h7标签，并生成链接。要使用该插件请在文章中添加&lt;!--TOC--&gt;标记，插件会用生成的链接替换掉该标记。<br/>我预计将在后续版本中增加其它导航功能，请跟踪<a href="http://www.tiaozhanshu.net/table-of-contents/" target="_blank">插件主页</a>。</p>
		</div>
	<form method="post">
		<div class="submit" style="float:right;border:none;padding-top:0px;padding-bottom:10px;">
			<input style="float:right;" type="submit" name="update_setting" value="<?php echo _e('Update setting','TOC'); ?>" />
			<input style="float:right;" type="submit" name="set_default" value="<?php echo _e('Load default','TOC');?>" />
		</div>
		<p>选择风格：<label style="margin-left:10px"><input type="radio" <?php echo ($options['style'] == "simple")?'checked="checked"':''; ?> class="tog" value="simple" name="style"/> <?php _e('Simple Style','style');?></label>
		<label style="margin-left:10px"><input type="radio" <?php echo ($options['style'] == "yskin")?'checked="checked"':''; ?> class="tog" value="yskin" name="style"/> <?php _e('Yskin Style','style');?></label>
		</p>
		<p>导航标题：<label for="title"></label><input type="text" name="title" value="<?php echo $options['title']?>" maxlength="25" /></p>
	</form>
</div>
<?php
}

function toc_option() {
	add_submenu_page('plugins.php', 'Table Of Contents', 'Table Of Contents', 9, __FILE__, 'toc_options_page');
}

function init_toc(){
	$options['style'] = 'simple';
	update_option('TOC',$options);
}

function toc_deactivation() {
	delete_option('TOC');
}

register_activation_hook(__FILE__, 'init_toc');
register_deactivation_hook(__FILE__,'toc_deactivation');
add_filter('the_content', array(new TableOfContents, 'toc_filter'), 9);
add_action('admin_menu', 'toc_option');
?>